 

<?php $__env->startSection('title', 'Categorias'); ?> 

<?php $__env->startSection('content'); ?> 

    <div class="d-flex justify-content-between align-items-center">
        <h1>Lista de Categorias</h1>
        <a href="/categories/create"  type="button" class="btn btn-primary">
            <i class="bi bi-plus-square"></i>
            <span>Nova Categoria</span>
        </a>
    </div>

    <table class="table">
        <thead>
            <tr>
                <th>ID CATEGORIA</th>
                <th>NOME</th>
                <th>DESCRIÇÃO</th>
                <th colspan="2">AÇÕES</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td> <?php echo e($category->id); ?></td>
                <td> <?php echo e($category->name); ?></td>
                <td> <?php echo e($category->descripton); ?></td>
                <td>
                    <a class='btn btn-primary' href="">
                        <i class='bi bi-pencil-square'></i>
                    </a> 
                </td>

                <td>
                    <form action="" method="post">
                        <button type="submit" name="excluir" class="btn btn-danger" onclick="return confirm('Tem certeza que deseja excluir a categoria?')">
                            <i class="bi bi-trash"></i>
                        </button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ifsc\Desktop\laravel\listaTarefa\resources\views/categories/index.blade.php ENDPATH**/ ?>