 

<?php $__env->startSection('title', 'Editar Tarefa'); ?> 

<?php $__env->startSection('content'); ?> 

<h1>Editar Tarefas</h1>

    <form action='/tasks/update/<?php echo e($task->id); ?>' method='post'>

        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        
        <div class="form-group">
            <label for="name">Nome Tarefa:</label>
            <input type="text" class="form-control" name="name" id="name" placeholder="Informe o nome da tarefa" required value='<?php echo e($task->name); ?>'>
        </div>

        <div class="form-group">
            <label for="descripton">Descrição Tarefa:</label>
            <input type="text" class="form-control" name="description" id="description" value='<?php echo e($task->description); ?>'
                placeholder="Informe a descrição da tarefa" required>
        </div>

        <div class="form-group">
            <label for="completed_date">Data Conclusão:</label>
            <input type="date" class="form-control" name="completed_date" id="completed_date" required value='<?php echo e($task->name); ?>'>
        </div>

        <div class="form-group d-flex flex-column">
            <label for="category_id">Categoria:</label>
            <select name="category_id" id="category_id">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($category['id']); ?>" <?php echo e($category['id'] == $task['category_id']? 'selected' : ''); ?>>
                    <?php echo e($category->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="form-group">
            <button type="submit" class="btn btn-primary">Salvar Alterações</button>
            <a href='/tasks' class="btn btn-secondary">Cancelar</a>
        </div>

    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ifsc\Downloads\laravel\laravel\listaTarefa\resources\views//tasks/edit.blade.php ENDPATH**/ ?>