<?php if(session('msg')): ?>
    <div class=message>
        <div class="alert alert-success">
            <?php echo e(session('msg')); ?>

        </div>
    </div>
<?php endif; ?><?php /**PATH C:\Users\ifsc\Desktop\laravel\listaTarefa\resources\views/layouts/message.blade.php ENDPATH**/ ?>