 

<?php $__env->startSection('title', 'Editar Categoria'); ?> 

<?php $__env->startSection('content'); ?> 

<h1>Editar Categorias</h1>

    <form action='/categories/update/<?php echo e($category->id); ?>' method='post'>

        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        
        <div class="form-group">
            <label for="name">Nome Categoria:</label>
            <input type="text" class="form-control" name="name" id="name" value='<?php echo e($category->name); ?>'
                placeholder="Informe o nome da categoria" required>
        </div>

        <div class="form-group">
            <label for="descripton">Descrição Categoria:</label>
            <input type="text" class="form-control" name="descripton" id="descripton" value='<?php echo e($category->descripton); ?>'
                placeholder="Informe a descrição da categoria" required>
        </div>

        <div class="form-group">
            <button type="submit" class="btn btn-primary">Salvar Alterações</button>
            <a href='/categories' class="btn btn-secondary">Cancelar</a>
        </div>

    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ifsc\Downloads\laravel\laravel\listaTarefa\resources\views//categories/edit.blade.php ENDPATH**/ ?>