 

<?php $__env->startSection('title', 'Cadastrar Categoria'); ?> 

<?php $__env->startSection('content'); ?> 

<h1>Cadastrar Categorias</h1>

    <form action='/categories' method='post'>

        <?php echo csrf_field(); ?>
        
        <div class="form-group">
            <label for="name">Nome Categoria:</label>
            <input type="text" class="form-control" name="name" id="name" placeholder="Informe o nome da categoria" required>
        </div>

        <div class="form-group">
            <label for="descripton">Descrição Categoria:</label>
            <input type="text" class="form-control" name="descripton" id="descripton"
                placeholder="Informe a descrição da categoria" required>
        </div>

        <div class="form-group">
            <button type="submit" class="btn btn-primary">Cadastrar</button>
            <button type="reset" class="btn btn-secondary">Limpar</button>
        </div>

    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ifsc\Desktop\laravel\listaTarefa\resources\views/categories/create.blade.php ENDPATH**/ ?>